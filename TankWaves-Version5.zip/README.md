# TankWaves Version 5 — Marketplace Core

Version 5 adds:

- Marketplace search, sorting, category, state, shipping, and pickup filters
- Favorites/watchlist
- Buyer inquiry forms routed to seller dashboards
- Seller ratings and written reviews
- Stronger store pages with policies, social links, banners, and logos
- Up to 10 Cloudinary photos per listing
- Featured listings and seller verification controls
- Basic environment-protected admin dashboard
- Responsive desktop and mobile design
- Existing Version 4 users, stores, listings, and photos remain compatible

## Existing Render service

Keep your current Render web service and PostgreSQL database.

Build command:

```text
pip install -r requirements.txt
```

Start command:

```text
gunicorn app:app
```

Required environment variables:

- `DATABASE_URL`
- `SECRET_KEY`
- `CLOUDINARY_URL`

Optional admin environment variable:

```text
ADMIN_EMAILS=your-email@example.com
```

Separate multiple admin emails with commas.

## Database note

The app uses `db.create_all()` so the new Version 5 tables are created without deleting existing users, stores, listings, or photos. For a larger production launch, switch to Flask-Migrate/Alembic before making future changes to existing columns.

## Important launch note

The free Render PostgreSQL database is suitable for development but expires. Upgrade or migrate the database before accepting real sellers, payments, or customer data.
